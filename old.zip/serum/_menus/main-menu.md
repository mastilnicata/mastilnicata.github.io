---
hidden: true
title: Main menu
menu: '[{"text":"Home","icon":"","href":"/","target":"_self","title":""},{"text":"About
  us","icon":"empty","href":"/about","target":"_self","title":""}]'
---
